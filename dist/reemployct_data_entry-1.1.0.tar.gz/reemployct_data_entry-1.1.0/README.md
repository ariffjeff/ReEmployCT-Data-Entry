# DOLWeeklyClaimDataEntry
 Automated entry of weekly certification data into Connecticut's DOL ReEmployCT portal.
