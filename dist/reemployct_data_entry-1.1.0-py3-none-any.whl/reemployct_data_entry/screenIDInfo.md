Each screenID is found by looking for a page element with the HTML ID "templateDivScreenId"

WC-800: Work Search Questionnaire
The page before work search record entry which asks if you actively looked for work last week and has a captcha

WC-802: Work Search Record Details
The entry form for where the data for each work search is entered (i.e. date of work search, employer name, position applied for, etc.)

WC-804: Weekly Certification and Work Search Record Acknowledgement
Work search confirmation page and entry of last 4 digits of SSN

WC-806: Work Search Summary
List of entered work searches for the current week

SUC-002: NO TITLE
Blank informational page displayed after submitting weekly work search, or...
"No Weeks are pending for the entered SSN", weekly certification entry not possible probably because it was already submitted for the week

WC-004: Weekly Certification Details
Weekly certification questions asked after work search data entry

WC-006: Verify Weekly Certification Responses
A summary of the previous page of weekly certification user choices.

WC-301: Employment Details
If you indicated on WC-004 that you performed any work for the previous week,
this page will load next asking for details on that work (employment status with this employer, $ earned, hours worked, etc.)

Special:
ReEmployCT home: no screenID
